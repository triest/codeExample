

<?php $__env->startSection('title', 'Page Title'); ?>

<?php $__env->startSection('content'); ?>


            <b> VIP анкеты</b><br><br>
            <?php $__currentLoopData = $vipGirls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $girl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <a href="<?php echo e(route('showGirl',['id'=>$girl->id])); ?>">
                            <img  height="300" width="300" src="<?php echo asset("/images/upload/$girl->main_image")?>"></a>
                        </a>
                            <h4 class="card-title">
                                <a href="<?php echo e(route('showGirl',['id'=>$girl->id])); ?>"><?php echo e($girl->name); ?></a>
                            </h4>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    <!--обычные -->



<b>Анкеты:</b><br> <br>
                    <?php $__currentLoopData = $girls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $girl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-md-4 col-sm-6 col-xs-6 portfolio-item">
                    <div class="card h-100">
                                <a href="<?php echo e(route('showGirl',['id'=>$girl->id])); ?>">
                                <img  height="250" width="250" src="<?php echo asset("/images/upload/$girl->main_image")?>"></a>
                                </a>
                                    <h4 class="card-title">
                                        <b> <a href="<?php echo e(route('showGirl',['id'=>$girl->id])); ?>"><?php echo e($girl->name); ?></a></b>
                                    </h4>
                            </div>
                        </div>
                <div class="col-md-1"></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




<?php echo $girls->render(); ?>




<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.js"></script>
<script>
    baguetteBox.run('.tz-gallery');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.blog3', ['title' => 'Список анкет'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>