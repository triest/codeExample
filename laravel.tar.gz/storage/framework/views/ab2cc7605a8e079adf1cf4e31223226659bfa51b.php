



<?php $__env->startSection('content'); ?>
<main>


    <!--обычные -->
    <div class="container">
        <div class="row">
            <div class="card h-100">
                <b> <p>Учетная запась: <?php echo e(Auth::user()->name); ?></p></b><br>
                <img height="250" src="<?php echo asset("/images/upload/$girl->main_image")?>"></img></a>
                <div class="card-body">

                   <b> <p>Анкета: <?php echo e($girl->name); ?></p></b>
                    <b> <p>Счет: <?php echo e($girl->money); ?></p></b>
                    <b> <p>Начало Vip статуса: <?php echo e($girl->beginvip); ?></p></b>
                    <b> <p>Окончане Vip статуса: <?php echo e($girl->endvip); ?></p></b>

                    <b>Payer:</b>
                    <form action="<?php echo e(route('payeer')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <label for="exampleInputFile">Введите сумму:</label>
                        <input type="number" in="money" name="money" value="300" required>
                      <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token">
                        <br>
                        <input type="submit" v-text="Оплатить">
                    </form>
                    <br>
                    <b>Яндекс деньги:</b>


                </div>
            </div>
        </div>
        <br>

        <a class="button blue" href="<?php echo e(route('main')); ?>" role="link">К списку анкет</a>
    </div>











<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.js"></script>
<script>
    baguetteBox.run('.tz-gallery');
</script>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.blog3',['title' => $girl->name], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>