<?php $__env->startSection('content'); ?>

    <!-- Main jumbotron for a primary marketing message or call to action -->

                <form action="<?php echo e(route('girlsCreate')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>


                    <div class="form-group">
                        <label for="title">Введите, которое будет отобрадаться:</label>
                        <input type="text" class="form-control" id="name" name="name" placeholder="Имя" required>
                    </div>


                    <div class="control-group2" ng-class="{true: 'error'}[submitted && form.pas.$invalid]">
                    <div class="form-group">
                        <label for="exampleInputFile">Введите телофон:</label>
                     <!--   <input type="tel" class="form-control" id="phone" name="phone" pattern="^\(\d{3}\)\d{3}-\d{2}-\d{2}$" required></input>-->
                        <input type="tel" class="form-control" id="phone" name="phone" required></input>

                    </div>
                    </div>
                    <label>Ваш пол:</label>
                    <label for="sex">Мужской:
                        <input type="radio" name="male">
                    </label>
                    <label for="sex">Женский:
                        <input type="radio" name="famele">
                    </label>
                    <div class="form-group">
                        <label for="exampleInputFile">Содержимое анкеты:</label>
                        <textarea class="form-control" name="description" required></textarea>
                    </div>

                    <label>Выберите заглавную фотографию</label>

                    <input type="file"  id="file"  name="file" value="<?php echo e(old('file')); ?>" required>
                    <br><br>
                    <script type="text/javascript" src="<?php echo e(asset('/js/tinymce/tinymce.min.js')); ?>"></script>
                    <script type="text/javascript">
                        tinymce.init({
                            selector : "textarea",
                            plugins : ["advlist autolink lists link image charmap print preview anchor", "searchreplace visualblocks code fullscreen", "insertdatetime media table contextmenu paste"],
                            toolbar : "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image"
                        });
                    </script>
                    <label>Выбирите фотографии для галереи(можно больше одной)</label>
                    <input required type="file"  class="form-control" name="images[]" placeholder="Фотографии" multiple  value="<?php echo e(old('file')); ?>">

                    <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token">
                    <br>
                    <button type="submit" class="btn btn-default">Submit</button>
                </form>

        <hr>
        <a class="button blue" href="<?php echo e(route('main')); ?>" role="link">К списку анкет</a>

    <script>
        //Код jQuery, установливающий маску для ввода телефона элементу input
        //1. После загрузки страницы,  когда все элементы будут доступны выполнить...
        $(function(){
            //2. Получить элемент, к которому необходимо добавить маску
            $("#phone").mask("8(999) 999-9999");
        });
    </script>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/js/bootstrap.min.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.blog3', ['title' => 'Создание анкеты'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>