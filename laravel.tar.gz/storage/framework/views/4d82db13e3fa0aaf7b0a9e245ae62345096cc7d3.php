

<?php $__env->startSection('content'); ?>



            <form action="<?php echo e(route('inputMobilePhone')); ?>" method="post" enctype="multipart/form-data" novalidate>
                <?php echo e(csrf_field()); ?>


                <div class="control-group2" ng-class="{true: 'error'}[submitted && form.pas.$invalid]">
                    <div class="form-group">
                        <label for="exampleInputFile">Введите телофон:</label>

                        <!--   <input type="tel" class="form-control" id="phone" name="phone" pattern="^\(\d{3}\)\d{3}-\d{2}-\d{2}$" required></input>-->
                        <input type="tel" class="form-control" id="phone" name="phone" required></input>

                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><b><?php echo e($error); ?></b></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <button type="submit" class="btn btn-default">Введите телефон</button>
            </form>

        </b>
        <script type="text/javascript">
            function phonenumber(inputtxt)
            {
                var phoneno = /^\d{10}$/;
                if(inputtxt.value.match(phoneno))
                {
                    return true;
                }
                else
                {
                    alert("Неверный  мобильный номер");
                    return false;
                }
            }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.blog3', ['title' => 'Ввод телефона:'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>