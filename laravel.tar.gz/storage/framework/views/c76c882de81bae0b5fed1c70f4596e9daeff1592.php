

<?php $__env->startSection('content'); ?>
    <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 portfolio-item">
        <a class="button blue" href="<?php echo e(route('girlsEditAuchAnket')); ?>">Редактировать анкету</a><br>
        <div class="container gallery-container">


            <div class="row">
                Загрузить фотографию:
                <form action="<?php echo e(route('uploadImage')); ?>" method="post" enctype="multipart/form-data" novalidate>
                    <?php echo e(csrf_field()); ?>

                    <input type="file"  id="file"  name="file" accept="image/x-png,image/gif,image/jpeg" value="<?php echo e(old('file')); ?>" required>
                    <?php if($errors->has('file')): ?>
                        <font color="red"><p>  <?php echo e($errors->first('file')); ?></p></font>
                    <?php endif; ?>
                    <button type="submit" class="btn btn-default">Загрузить фотографию</button>
                </form>
            </div>
            <br>
            <div class="container gallery-container">
                <div class="tz-gallery">
                    <div class="row">
                        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-3 col-md-4 col-sm-6 col-xs-5 portfolio-item">
                                <img  height="250" src="<?php echo asset("public/images/upload/$image->photo_name")?>">
                                <a class="button blue" href="<?php echo e(route('deleteImage',['id'=>$image->photo_name])); ?>" role="link">Удалить</a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- Placed at the end of the document so the pages load faster -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.blog3', ['title' => 'Редактирование галереи'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>