

<?php $__env->startSection('content'); ?>

    Введите код активации. Доставка SMS может занять несколько минут.
    <form action="<?php echo e(route('inputActiveCode')); ?>" method="post"  novalidate>
        <?php echo e(csrf_field()); ?>

        <input type="text" class="form-control" id="code" name="code" required></input>

        <button type="submit" class="btn btn-default">Введите код автивации</button>
    </form>
    <a class="button blue" href="<?php echo e(route('inputMobile')); ?>" role="link">Вернуться и попробовать заново</a>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.blog3', ['title' => 'Введите код активации:'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>