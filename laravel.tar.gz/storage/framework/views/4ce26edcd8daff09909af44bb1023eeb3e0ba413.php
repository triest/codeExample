<!doctype html>
<head>

</head>
<body>
Подтвердите регистрацию переходом по <a href=http://sakura-city.info/user/confernd/<?php echo e($token); ?>> ссылке.</a><br>
Если ссылка не активна, то скопируюте её в адресную строку браузера.
http://sakura-city.info/user/confernd/<?php echo e($token); ?>

</body>
</html>