

<?php $__env->startSection('title', 'Page Title'); ?>

<?php $__env->startSection('content'); ?>

    Подтвердите ваш адрес электронной почты. После нажатия на кнопку на Ваш адрес <b><?php echo e($email); ?></b>  придет электронное письмо.
    Для активаци учетной запись перейдите по ссылке в письме.
<br>
    <a class="button green" href="<?php echo e(route('sendConfurmEmail')); ?>" role="link">Отправить письмо</a>
<br>
    <a class="button blue" href="<?php echo e(route('main')); ?>" role="link">К списку анкет</a>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.blog3', ['title' => 'Подтвердите email'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>