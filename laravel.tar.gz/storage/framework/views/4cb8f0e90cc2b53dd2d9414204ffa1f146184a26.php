

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('yandexPost')); ?>" method="post" >
    

        <button type="submit" class="btn btn-default">Протестировать</button>
    </form>



    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.blog3', ['title' => 'Тестирование запроса'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>