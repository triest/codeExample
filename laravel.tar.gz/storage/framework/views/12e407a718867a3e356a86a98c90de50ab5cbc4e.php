

<?php $__env->startSection('title', 'Page Title'); ?>

<?php $__env->startSection('content'); ?>

<b>Анкеты:</b><br> <br>
                    <?php $__currentLoopData = $girls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $girl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!--телефон -col-xs-8 -->
                        <!-- сol-lg-3 компьютер-->
                <div class="col-lg-4 col-md-6 col-sm-8 col-xs-9 portfolio-item">
                    <div class="card h-100">
                                <a href="<?php echo e(route('showGirl',['id'=>$girl->id])); ?>">
                                <img  height="250" width="250" src="<?php echo asset("public/images/upload/$girl->main_image")?>"></a>
                                </a>
                                    <h4 class="card-title">
                                        <b> <a href="<?php echo e(route('showGirl',['id'=>$girl->id])); ?>"><?php echo e($girl->name); ?></a></b>
                                    </h4>
                            </div>
                        </div>
                <div class="col-md-1"></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




<?php echo $girls->render(); ?>




<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.js"></script>
<script>
    baguetteBox.run('.tz-gallery');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.blog3', ['title' => 'Список анкет'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>