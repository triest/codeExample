<?php
/**
 * Created by PhpStorm.
 * User: triest
 * Date: 08.06.2018
 * Time: 0:41
 */

namespace App;


class Services
{
    protected $fillable=['id','name'];
}