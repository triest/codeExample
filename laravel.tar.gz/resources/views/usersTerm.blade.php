@extends('layouts.blog3', ['title' => 'Пользовательское соглашение'])

@section('title', 'Page Title')

@section('content')

    @endsection