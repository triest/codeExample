<!doctype html>
<head>

</head>
<body>
<hreaf='sakura-city.info'>sakura-city.info</hreaf>
Если ссылка не активна, то скопируюте её в адресную строку брузера.

</body>
</html>