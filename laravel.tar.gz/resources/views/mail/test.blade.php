<!doctype html>
<head>

</head>
<body>
<a href=http://sakura.city.xsph.ru/public/user/confernd/>Подтвердите регистрацию переходом по ссылке.</a>
Если ссылка не активна, то скопируюте её в адресную строку брузера.

</body>
</html>