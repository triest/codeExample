
[SENDER]sakura-city[/SENDER][SMS]ДОБРО ПОЖАЛОВАТЬ[/SMS].
